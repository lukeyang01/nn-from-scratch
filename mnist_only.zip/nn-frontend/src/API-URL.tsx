export const api_url = "http://0.0.0.0:8000/api/";
