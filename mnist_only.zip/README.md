# MNIST ONLY

## Releases

[MNIST only](/releases/mnist_only.zip)

## TODO:

- Add nn.py file containing model into nn-backend

- Add mnist_weights.npy and mnist_biases.npy into nn-backend/data

- Update nn-endpoint.py to include layer information

- Update App.tsx to include parameter information
